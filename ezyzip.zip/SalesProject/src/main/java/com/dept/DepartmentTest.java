package com.dept;



import java.util.Iterator;

import java.util.List;



import javax.persistence.Query;



import org.hibernate.Session;

import org.hibernate.SessionFactory;

import org.hibernate.Transaction;

import org.hibernate.boot.Metadata;

import org.hibernate.boot.MetadataSources;

import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import org.hibernate.service.ServiceRegistry;

public class DepartmentTest {
	public static void main(String args[])
	{
		Department dept1 = new Department();
		dept1.setDepartmentNumber(40);
		dept1.setDepartmentName("QMS");
		dept1.setDepartmentLocation("Mumbai");
	
		System.out.println("deptno :"+dept1.getDepartmentNumber());
		System.out.println("deptname :"+dept1.getDepartmentName());
		System.out.println("deptloc :"+dept1.getDepartmentLocation());
		
		
		ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		System.out.println("This is service Registry:"+serviceRegistry);
		Metadata metadata = new MetadataSources(serviceRegistry).getMetadataBuilder().build();
		System.out.println("This is Metadata"+metadata);
		SessionFactory factory = metadata.getSessionFactoryBuilder().build();
		System.out.println("This is session factory"+factory);
		
		Session session = factory.getCurrentSession();
		System.out.println("=>session.."+session);
		
		Transaction tx = session.beginTransaction();
		System.out.println("=>transaction.."+tx);
		
//		session.save(dept1);
//		tx.commit();
		System.out.println("=>transaction..committed..."+tx);
		//System.out.println("Closing Session Factory ..");
		//factory.close();
		
		//normal select query in hibernate
		Query query = session.createQuery("from Department",Department.class); //HQL - hibernate query language
		List<Department> deptList = query.getResultList();
		Iterator<Department> deptIter = deptList.iterator();
		
		System.out.println("current table is ");
		while(deptIter.hasNext()) {
			Department dept = deptIter.next();
			System.out.println("deptno : "+dept.getDepartmentNumber());
			System.out.println("name   : "+dept.getDepartmentName());
			System.out.println("loc    : "+dept.getDepartmentLocation());
			System.out.println("-------------------------");
			
			
	  		
		}
		//UPDATE - first seek the object
		try {
				Department dept3 = session.find(Department.class, 50);
				//now the object if found,  IT IS SENSITIVE TO CHANGES 
				//BECAUSE IT IS AN ATTACHED OBJECT WITH ORM AND DB
				System.out.println("deptno : "+dept3.getDepartmentNumber());
				System.out.println("name   : "+dept3.getDepartmentName());
				System.out.println("loc    : "+dept3.getDepartmentLocation());
				System.out.println(">> call the required setter methods ");
				dept3.setDepartmentName("IT");
				dept3.setDepartmentLocation("SHIRDI");
				session.update(dept3);
				
		}
		catch(NullPointerException e)
		{
			System.out.println("table to be updated is not found");
		}
				
				
				/* UPDATE IT PRESUMING 60 IS PRESENT IN THE DB
				 * Department dept3 = new Department();
				dept3.setDepartmentNumber(60);
				dept3.setDepartmentName("TESTing");
				dept3.setDepartmentLocation("Bangalore");
				session.saveOrUpdate(dept3);
				*/
		
		
		//insert
		Department dept2 = new Department();
		dept2.setDepartmentNumber(70);
		dept2.setDepartmentName("QMS");
		dept2.setDepartmentLocation("Mumbai");
		session.save(dept2);
		System.out.println("data inserted brooooooooooo");
		
        tx.commit();
		
		System.out.println("=>transaction..committed..."+tx);
		
		System.out.println("Closing Session Factory ..");
		factory.close();
		System.out.println("Session Factory is closed..");	
	}
}